import xbmc
import xbmcaddon
import wmi
 
__addon__       = xbmcaddon.Addon(id='plugin.video.helloworld')
__addonname__   = __addon__.getAddonInfo('name')
__icon__        = __addon__.getAddonInfo('icon')

title = "PC-CPU ID"
time = 5000  # ms
c = wmi.WMI()


for s in c.Win32_Processor():
    if s == 24:
xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(title, s, time, __icon__))
        break
 
